chrome.devtools.panels.create(
  "Azure Permission Lookup",
  "",
  "panel.html"
);
