
const container = document.getElementById("container");
const searchInput = document.getElementById("search");
const exportBtn = document.getElementById("exportBtn");

let failures = [];
const operationRegex = /Microsoft\.[A-Za-z0-9./-]+/;

function leastPrivilegeRole(operation) {
  if (!operation) return null;

  if (operation.includes("KeyVault/vaults/secrets/read"))
    return "Key Vault Secrets User";

  if (operation.includes("KeyVault"))
    return "Key Vault Reader";

  if (operation.includes("Network"))
    return "Network Reader";

  if (operation.includes("Storage/blobServices"))
    return "Storage Blob Data Reader";

  if (operation.includes("Compute"))
    return "Virtual Machine Reader";

  return null;
}

function buildCustomRoleJSON(operation, subscription) {
  return JSON.stringify({
    "Name": "Custom-Least-Privilege-" + operation.replace(/[\/\.]/g, "-"),
    "IsCustom": true,
    "Description": "Least privilege role for specific Azure operation.",
    "Actions": [
      operation
    ],
    "NotActions": [],
    "AssignableScopes": [
      "/subscriptions/" + subscription
    ]
  }, null, 2);
}

function render() {
  const filter = searchInput.value.toLowerCase();
  container.innerHTML = "";

  failures
    .filter(f => 
      f.subscription.toLowerCase().includes(filter) ||
      f.resourceGroup.toLowerCase().includes(filter) ||
      f.resource.toLowerCase().includes(filter) ||
      f.operation.toLowerCase().includes(filter)
    )
    .forEach(f => {
      const card = document.createElement("div");
      card.className = "card";

      let suggestionHTML = "";

      if (f.builtInRole) {
        suggestionHTML = `<div><span class="label">Least Privileged Built-In Role:</span> ${f.builtInRole}</div>`;
      } else {
        suggestionHTML = `
          <div><span class="label">Suggested Role:</span> Custom Role Required</div>
          <div><span class="label">Custom Role JSON:</span></div>
          <pre>${f.customRoleJSON}</pre>
        `;
      }

      card.innerHTML = `
        <div><span class="label">Subscription:</span> ${f.subscription}</div>
        <div><span class="label">Resource Group:</span> ${f.resourceGroup}</div>
        <div><span class="label">Azure Resource:</span> ${f.resource}</div>
        <div><span class="label">Status:</span> <span class="status">${f.status}</span></div>
        <div><span class="label">Required Operation:</span> ${f.operation}</div>
        ${suggestionHTML}
      `;

      container.appendChild(card);
    });
}

searchInput.addEventListener("input", render);

exportBtn.addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(failures, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "azure-permission-failures.json";
  a.click();
});

chrome.devtools.network.onRequestFinished.addListener(function(request) {
  if (!request.response || request.response.status < 400) return;

  request.getContent(function(content) {
    if (!content) return;

    try {
      const message = content;

      const operationMatch = message.match(operationRegex);
      if (!operationMatch) return;

      const subMatch = message.match(/subscriptions\/([a-z0-9-]+)/i);
      const rgMatch = message.match(/resourcegroups\/([a-z0-9-]+)/i);
      const resourceMatch = message.match(/vaults\/([a-z0-9-]+)/i);

      const subscription = subMatch ? subMatch[1] : "N/A";
      const operation = operationMatch[0];

      const builtIn = leastPrivilegeRole(operation);

      const failure = {
        subscription: subscription,
        resourceGroup: rgMatch ? rgMatch[1] : "N/A",
        resource: resourceMatch ? resourceMatch[1] : "N/A",
        status: request.response.status.toString(),
        operation: operation,
        builtInRole: builtIn,
        customRoleJSON: builtIn ? null : buildCustomRoleJSON(operation, subscription)
      };

      if (!failures.some(f =>
        f.subscription === failure.subscription &&
        f.operation === failure.operation &&
        f.resource === failure.resource
      )) {
        failures.unshift(failure);
        render();
      }

    } catch {}
  });
});
